
[Cart Pole](https://gym.openai.com/envs/CartPole-v0)

* Cart Pole (v0 and v1) on the gym(OpenAI). 
* Using passive TD learning or Q learning with neural network for function approximation.
* Tenser flow, numpy

![alt tag](https://cdn-images-1.medium.com/max/1600/1*ohWngM-PVYmDG9KVpOm_xQ.gif)
